<?php

namespace app\component\telegram;

/**
 * Class InvalidJsonException
 *
 * @codeCoverageIgnore
 * @package app\component\telegram
 */
class InvalidJsonException extends Exception
{

}
