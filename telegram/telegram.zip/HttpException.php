<?php

namespace app\component\telegram;

/**
 * Class HttpException
 *
 * @codeCoverageIgnore
 * @package app\component\telegram
 */
class HttpException extends Exception
{

}
