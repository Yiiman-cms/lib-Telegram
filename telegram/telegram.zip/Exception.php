<?php

namespace app\component\telegram;

/**
 * Class Exception
 *
 * @codeCoverageIgnore
 * @package app\component\telegram
 */
class Exception extends \Exception
{

}
