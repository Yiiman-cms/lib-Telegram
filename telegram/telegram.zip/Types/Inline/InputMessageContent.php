<?php
/**
 * Created by PhpStorm.
 * User: iGusev
 * Date: 14/04/16
 * Time: 04:05
 */

namespace app\component\telegram\Types\Inline;

use app\component\telegram\BaseType;

class InputMessageContent extends BaseType
{

}
