<?php

namespace app\component\telegram;

interface TypeInterface
{
    public static function fromResponse($data);
}
