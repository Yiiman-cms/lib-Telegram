<?php

namespace app\component\telegram;

/**
 * Class BadMethodCallException
 *
 * @codeCoverageIgnore
 * @package app\component\telegram
 */
class BadMethodCallException extends Exception
{

}
