<?php

namespace app\component\telegram;

/**
 * Class InvalidArgumentException
 *
 * @codeCoverageIgnore
 * @package app\component\telegram
 */
class InvalidArgumentException extends Exception
{

}
